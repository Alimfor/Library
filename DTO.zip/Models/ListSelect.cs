﻿namespace library.Models
{
    public class ListSelect
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
