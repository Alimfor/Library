﻿namespace Library.Models
{
    public class Category
    {
        public int categoryId { get; set; }
        public string name { get; set; }
    }
}
