﻿namespace Library.Models
{
    public class Author
    {
        public int authorId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
    }
}
