﻿namespace Library.Utils
{
    public class BookDetails
    {
        public string bookName { get; set; }
        public string authorName { get; set; }
        public string categoryName { get; set; }
    }
}
