﻿namespace Library.Utils
{
    public enum Status
    {
        SUCCESSFUL,
        WRONG_REQUEST,
        ERROR
    }
}
