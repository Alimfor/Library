﻿namespace Library.Utils
{
    public class Result
    {
        public string message { get; init; }
        public int code { get; init; }
        public Status status { get; init; }
    }
}
