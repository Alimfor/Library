﻿namespace Library.DTO;

public class AuthorDTO
{
    public string firstName { get; init; }
    public string lastName { get; init; }
}