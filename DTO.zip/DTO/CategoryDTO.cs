﻿namespace Library.DTO;

public class CategoryDTO
{
    public string name { get; init; }
}